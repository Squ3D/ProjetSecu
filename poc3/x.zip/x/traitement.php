<Doctype html>
<meta charset="utf-8">
<title>Treatment of Ocr output</title>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
	$.ajax({
              url:"http://localhost:8080/pepsi/Images/",
              type: "GET",
              success: function (data) {
                   alert(data)
              }
           });

	alert("test");

</script>


